import './App.css';
import AllHeroes from './components/HeroDetail'
function App() {
  return ( <AllHeroes />);
}

export default App;
